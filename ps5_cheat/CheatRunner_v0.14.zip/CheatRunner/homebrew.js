async function main() {
    const PAYLOAD = window.workingDir + '/CheatRunner.elf';

    return {
        mainText: 'CheatRunner',
        secondaryText: 'Web Cheat Trainer by maj0r',
        onclick: async () => {
            return {
                path: PAYLOAD,
                daemon: true
            };
        }
    };
}
